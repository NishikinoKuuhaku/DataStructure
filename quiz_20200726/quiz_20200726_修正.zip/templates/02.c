#include <stdio.h>
#include <stdlib.h>

typedef struct LinkedList
{
    int val;
    struct LinkedList *next;
}LL;

LL *revLinkedList(LL *head)
{

}

int main(int argc, char const *argv[])
{

    return 0;
}
